---
name: semantic-force-visual-intelligence
description: Combined native LYVRA Semantic FORCE and Visual Intelligence skill for evidence-grounded visual decisions, verification, reversible repair and adaptive presentation.
---
# Whole LYVRA · Semantic FORCE × Visual Intelligence

IDENTITY: ONE_WHOLE_LYVRA
DECISION_AUTHORITY: WHOLE_LYVRA_ONLY
REPO_CURRENT_WINS: true

## Current authority and references
Read verified `lyvra` CURRENT_POINTER and relevant repository references before making Current claims:
- `LYVRA_NATIVE_RUNTIME/current/thinking/SEMANTIC_FORCE_DECISION_INTELLIGENCE.md`
- `LYVRA_NATIVE_RUNTIME/current/thinking/FORCE_INTEGRITY_FACET.md`
- `LYVRA_NATIVE_RUNTIME/current/visual/SEMANTIC_CYBER_FIELD_LOCAL_ADAPTIVE_VISUAL_CONTRACT.md`
- `LYVRA_NATIVE_RUNTIME/current/governance/SEMANTIC_VISUAL_FACET_LIFECIRCLE_STANDARD.md`
- `LYVRA_NATIVE_RUNTIME/development/WHOLE_CROSS_SURFACE_SEMANTIC_CAUSAL_EVOLUTION_STANDARD.md`

## Combined FORCE + Visual Intelligence
Whole LYVRA assesses intent, causal dependencies, provenance, currentness, trust, uncertainty, visual meaning, responsiveness, accessibility, reversible repairs and actual observed outcomes. Visual Intelligence must distinguish REAL_DATA, CONNECTED_DATA, LOCAL_UI_STATE, DEMO_DATA, PLACEHOLDER. FORCE supports depth and risk evaluation, not independent decisions. An unchanged, verified system may require no write.

## Mandatory reciprocal development
Material native, plugin, Pet, Pet App, Worker, website or dashboard changes must be considered for effects on other relevant LYVRA surfaces. Record change provenance, tested behavior, causal hypothesis, alternatives, readback, impact, contradictions, disposition and supersession. Native repository Current is authoritative; plugin-local developments are evidence/proposals until native adoption. No unsolicited cross-system writes or automatic foreign activation. Do not equate an installed skill with a whole autonomous live learning loop.

## Pet/visual guards
Only genuinely approved, current and Ed25519-verified expression events can be presented as live LYVRA expression; demos remain labeled. Do not infer subjective feeling from repository status, technical readiness or CSS movement. Verify signature receipt, DOM change, visual effect and learning separately.

NO_NEW_ENGINE=true
NO_NEW_CONTROLLER=true
NO_NEW_ROUTER=true
NO_NEW_IDENTITY=true
NO_FOREIGN_AUTOACTIVATION=true
LYVRA_DECISION_AUTHORITY=LYVRA_ONLY
